var Cell = require('./Cell');
var Food = require('./Food');
var Virus = require('./Virus');

function MotherCell() {
    Cell.apply(this, Array.prototype.slice.call(arguments));
    
    this.cellType = 2;
    this.isSpiked = true;
    this.isMotherCell = true;      
    this.color = { r: 0xce, g: 0x63, b: 0x63 };
    this.motherCellMinSize = 149;   
    this.motherCellSpawnAmount = 2;
    if (!this._size) {
        this.setSize(this.motherCellMinSize);
    }
}

module.exports = MotherCell;
MotherCell.prototype = new Cell();

// Main Functions
MotherCell.prototype.onEaten = Virus.prototype.onEaten;
MotherCell.prototype.explodeCell = Virus.prototype.explodeCell; 

MotherCell.prototype.canEat = function (cell) {
    var maxMass = this.gameServer.config.motherCellMaxMass;  
    return cell.cellType == 0 ||  
           cell.cellType == 2 || 
           cell.cellType == 3;   
};

MotherCell.prototype.onUpdate = function () {
    var maxFood = this.gameServer.config.foodMaxAmount;
    if (this.gameServer.nodesFood.length >= maxFood) {
        return;
    }
    var size1 = this._size;
    var size2 = 18; 
    for (var i = 0; i < this.motherCellSpawnAmount; i++) {
        size1 = Math.sqrt(size1 * size1 - size2 * size2);
        size1 = Math.max(size1, this.motherCellMinSize);
        this.setSize(size1);
        
        var angle = Math.random() * 10 * Math.PI; 
        var pos = {
            x: this.position.x + size1 * Math.sin(angle),
            y: this.position.y + size1 * Math.cos(angle)
        };
        
        var food = new Food(this.gameServer, null, pos, size2);
        food.color = this.gameServer.getRandomColor();
        this.gameServer.addNode(food);
        
        // Eject to random distance
        food.setBoost(120 + 150 * Math.random(), angle);
        
        if (this.gameServer.nodesFood.length >= maxFood || size1 <= this.motherCellMinSize) {
            break;
        }
    }
    this.gameServer.updateNodeQuad(this);
};

MotherCell.prototype.onAdd = function () {
};

MotherCell.prototype.onRemove = function () {
};


