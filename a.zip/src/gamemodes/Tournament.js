var Mode = require('./Mode');
var Entity = require('../entity');

function Tournament() {
    Mode.apply(this, Array.prototype.slice.call(arguments));

    this.ID = 4;
    this.name = "Agar 서바이벌";
    this.packetLB = 48;
    this.IsTournament = true;
    // Config (1 tick = 1000 ms)
    this.prepTime = 5; // Amount of ticks after the server fills up to wait until starting the game
    this.endTime = 15; // Amount of ticks after someone wins to restart the game
    this.autoFill = false;
    this.autoFillPlayers = 1;
    this.dcTime = 0;

    // Gamemode Specific Variables
    this.gamePhase = 0; // 0 = Waiting for players, 1 = Prepare to start, 2 = Game in progress, 3 = End
    this.contenders = [];
    this.maxContenders = 80;
    this.isPlayerLb = false;
     this.nodesMother = [];
    this.motherSpawnInterval = 125; 
    this.motherMinAmount = 10;
    this.winner;
    this.timer;
    this.timeLimit = 3600; // in seconds
}

module.exports = Tournament;
Tournament.prototype = new Mode();

// Gamemode Specific Functions
Tournament.prototype.spawnMotherCell = function (gameServer) {
    // Checks if there are enough mother cells on the map
    if (this.nodesMother.length >= this.motherMinAmount) {
        return;
    }
    // Spawn if no cells are colliding
    var mother = new Entity.MotherCell(gameServer, null, gameServer.randomPos(), 149);
    if (!gameServer.willCollide(mother))
        gameServer.addNode(mother);
};

// Override

Tournament.prototype.onServerInit = function (gameServer) {
    // Called when the server starts
    this.prepare(gameServer);
    
    // Ovveride functions for special virus mechanics
    var self = this;
    Entity.Virus.prototype.onEat = function (prey) {
        // Pushes the virus
        this.setBoost(220, prey.boostDirection.angle());
    };
    Entity.MotherCell.prototype.onAdd = function () {
        self.nodesMother.push(this);
    };
    Entity.MotherCell.prototype.onRemove = function () {
        var index = self.nodesMother.indexOf(this);
        if (index != -1) 
            self.nodesMother.splice(index, 1);
    };
};

Tournament.prototype.onTick = function (gameServer) {
    // Mother Cell Spawning
    if ((gameServer.tickCounter % this.motherSpawnInterval) === 0) {
        this.spawnMotherCell(gameServer);
    }
    var updateInterval;
    for (var i = 0; i < this.nodesMother.length; ++i) {
        var motherCell = this.nodesMother[i];

        if (motherCell._size <= motherCell.motherCellMinSize)
            updateInterval = Math.random() * (50 - 25) + 25;
        else
            updateInterval = 2;

        if ((gameServer.tickCounter % ~~updateInterval) === 0) {
            motherCell.onUpdate();
        }
    }
};

Tournament.prototype.startGame = function (gameServer) {
    gameServer.run = true;
    this.gamePhase = 1;
    this.getSpectate(); // Gets a random person to spectate
    gameServer.config.playerDisconnectTime = this.dcTime; // Reset config
};

Tournament.prototype.endGame = function (gameServer) {
    this.winner = this.contenders[0];
    this.gamePhase = 2;
    this.timer = this.endTime; // 30 Seconds
};

Tournament.prototype.endGameTimeout = function (gameServer) {
    gameServer.run = false;
    this.gamePhase = 3;
    this.timer = this.endTime; // 30 Seconds
};

Tournament.prototype.fillBots = function (gameServer) {
    // Fills the server with bots if there arent enough players
    var fill = this.maxContenders - 45 - this.contenders.length;
    for (var i = 0; i < fill; i++) {
        gameServer.bots.addBot();
    }
};
Tournament.prototype.getSpectate = function () {
// Finds a random person to spectate
    var index = Math.floor(Math.random() * this.contenders.length);
    this.rankOne = this.contenders[index];
};

Tournament.prototype.prepare = function (gameServer) {
    // Remove all cells
    var len = gameServer.nodes.length;
    for (var i = 0; i < len; i++) {
        var node = gameServer.nodes[0];

        if (!node) {
            continue;
        }

        gameServer.removeNode(node);
    }

    //Kick all bots for restart.
    for (var i = 0; i < gameServer.clients.length; i++) {
        if (gameServer.clients[i].isConnected != null)
            continue; // verify that the client is a bot
        gameServer.clients[i].close();
    }

    gameServer.bots.loadNames();

    // Pauses the server
    gameServer.run = true;
    this.gamePhase = 0;

    // Get config values
    if (gameServer.config.tourneyAutoFill > 0) {
        this.timer = gameServer.config.tourneyAutoFill;
        this.autoFill = true;
        this.autoFillPlayers = gameServer.config.tourneyAutoFillPlayers;
    }
    // Handles disconnections
    this.dcTime = gameServer.config.playerDisconnectTime;
    gameServer.config.playerDisconnectTime = 0;

    this.prepTime = gameServer.config.tourneyPrepTime;
    this.endTime = gameServer.config.tourneyEndTime;
    this.maxContenders = gameServer.config.tourneyMaxPlayers;

    // Time limit
    this.timeLimit = gameServer.config.tourneyTimeLimit * 60; // in seconds
};

Tournament.prototype.onPlayerDeath = function (gameServer) {

    // Nothing
};

Tournament.prototype.formatTime = function (time) {
    if (time < 0) {
        return "0:00";
    }
    // Format
    var min = Math.floor(this.timeLimit / 60);
  var sec = this.timeLimit % 60;
    sec = (sec > 9) ? sec : "0" + sec.toString();
    return min + ":" + sec;
};

// Override


Tournament.prototype.onPlayerSpawn = function (gameServer, player) {
        if ((this.contenders.length < this.maxContenders)) {
    // Only spawn players if the game hasnt started yet
        player.color = gameServer.getRandomColor(); // Random color
        this.contenders.push(player); // Add to contenders list
        gameServer.spawnPlayer(player, gameServer.randomPos());
        }
                 }

Tournament.prototype.onCellRemove = function (cell) {
    var owner = cell.owner,
        human_just_died = false;

    if (owner.cells.length <= 0) {
        // Remove from contenders list
        var index = this.contenders.indexOf(owner);
        if (index != -1) {
            if ('_socket' in this.contenders[index].socket) {
                human_just_died = true;
            }
            this.contenders.splice(index, 1);
        }

        // Victory conditions
        var humans = 0;
        for (var i = 0; i < this.contenders.length; i++) {
            if ('_socket' in this.contenders[i].socket) {
                humans++;
            }
        }

        // the game is over if:
        // 1) there is only 1 player left, OR
        // 2) all the humans are dead, OR
        // 3) the last-but-one human just died
        if ((this.contenders.length == 1 || humans == 0 || (humans == 1 && human_just_died)) && this.gamePhase == 1) {
            this.endGame(cell.owner.gameServer);
        } else {
              // Do stuff
            this.onPlayerDeath(cell.owner.gameServer);
        }
    }
};
Tournament.prototype.updateLB_FFA = function (gameServer, lb) {
    gameServer.leaderboardType = 49;
    for (var i = 0, pos = 0; i < gameServer.clients.length; i++) {
        var player = gameServer.clients[i].playerTracker;
        if (player.isRemoved || !player.cells.length ||
            player.socket.isConnected == false || player.isMi)
 continue;

        for (var j = 0; j < pos; j++)
            if (lb[j]._score < player._score) break;

        lb.splice(j, 0, player);
        pos++;
    }
    this.rankOne = lb[0];
};

Tournament.prototype.updateLB = function (gameServer, lb) {
    gameServer.leaderboardType = this.packetLB;
    switch (this.gamePhase) {
        case 0:
        lb[0] = "셀프피드 모드";
        lb[1] = "인원수 : ";
        lb[2] = this.contenders.length + " / " + this.maxContenders;
        lb[3] = "최소 인원 : 3명";
        if (this.autoFill) {
            if (this.timer <= 0) {
                this.startGame(gameServer);
                this.fillBots(gameServer);
            } else if (this.contenders.length >= this.autoFillPlayers) {
                lb[3] = "-----------------";
                lb[4] = this.timer.toString() + " 초";
                lb[5] = "후에 시작합니다";
                this.timer--;
            }
        }
        break;
            case 1:
            if (!this.isPlayerLb) {
                gameServer.leaderboardType = this.packetLB;
                lb[0] = "셀프피드 모드";
                lb[1] = "생존자 : " + this.contenders.length + " / " + this.maxContenders + " 명";
                lb[2] = "제한 시간 : ";
                lb[3] = this.formatTime(this.timeLimit) + " 분";
            } else {
                this.updateLB_FFA(gameServer, lb);
            }
            if (this.timeLimit < 0) {
                // Timed out
                this.endGame(gameServer);
            } else {
                if (this.timeLimit % gameServer.config.tourneyLeaderboardToggleTime == 0) {
                    this.isPlayerLb ^= true;
                }
                this.timeLimit--;
            }
            break;
        case 2:
            lb[0] = "셀프피드 모드";
            lb[1] = "Agar 서바이벌";
            lb[2] = this.winner._name;
            lb[3] = "승리";
            lb[4] = "-----------------";
            if (this.timer <= 0) {
                // Reset the game
                this.onServerInit(gameServer);
   } else {
  lb[5] = this.timer.toString() + " 초 후에";
                lb[6] = "서버를 리셋합니다";
                this.timer--;
            }
        default:
            break;
    }
};

