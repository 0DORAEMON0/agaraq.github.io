var BinaryWriter = require("./BinaryWriter");

function AddNode(playerTracker,item){this.playerTracker=playerTracker;this.item=item}module.exports=AddNode;AddNode.prototype.build=function(protocol){var writer=new BinaryWriter;writer.writeUInt8(32);writer.writeUInt32((this.item.nodeId^this.playerTracker.scrambleId)>>>0);return writer.toBuffer()};
