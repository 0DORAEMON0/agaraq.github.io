var Logger = require('./Logger');
var UserRoleEnum = require("../enum/UserRoleEnum");

function PlayerCommand(gameServer, playerTracker) {
    this.gameServer = gameServer;
    this.playerTracker = playerTracker;
}

module.exports = PlayerCommand;

PlayerCommand.prototype.writeLine = function (text) {
    this.gameServer.sendChatMessage(null, this.playerTracker, text);
};

PlayerCommand.prototype.executeCommandLine = function (commandLine) {
    if (!commandLine) return;

    // Splits the string
    var args = commandLine.split(" ");

    // Process the first string value
    var first = args[0].toLowerCase();

    // Get command function
    var execute = playerCommands[first];
    if (typeof execute != 'undefined') {
        execute.bind(this)(args);
    } else {
        this.writeLine("ERROR: Unknown command, type /help for command list");
    }
};

var playerCommands = {
    help: function (args) {
            this.writeLine("-----------------------------------------------------------------------");
            this.writeLine("/kill - 자신의 세포를 죽일수있습니다");
            this.writeLine("/help - 명령어 목록을 불러옵니다");
            this.writeLine("/id - 플레이어 아이디를 확인할수있습니다");
            this.writeLine("/status - 서버의 상태를 확인합니다");
            this.writeLine("-----------------------------------------------------------------------");
    },


    id: function (args) {
        this.writeLine("플레이어 아이디 : " + this.playerTracker.pID);
    },
    kill: function (args) {
        if (!this.playerTracker.cells.length) {
            this.writeLine("자신의 세포를 죽였습니다");
            return;
        }
        while (this.playerTracker.cells.length) {
            var cell = this.playerTracker.cells[0];
            this.gameServer.removeNode(cell);
            // replace with food
            var food = require('../entity/Food');
            food = new food(this.gameServer, null, cell.position, cell._size);
            food.color = cell.color;
            this.gameServer.addNode(food);
        }
        this.writeLine("자신의 세포를 죽였습니다");
    },

  
    status: function (args) {    
        // Get amount of humans/bots
        var humans = 0,
            bots = 0;
        for (var i = 0; i < this.gameServer.clients.length; i++) {
            if ('_socket' in this.gameServer.clients[i]) {
                humans++;
            } else {
                bots++;
            }
        }
        var ini = require('./ini.js');
        this.writeLine("----------------------------------------------------------");
        this.writeLine("모든 Player : " + this.gameServer.clients.length + "/" + this.gameServer.config.serverMaxConnections);
        this.writeLine("플레이어 : " + humans + " - 봇: " + bots);
        this.writeLine("서버 가동 시간 : " + Math.floor(process.uptime() / 60) + " 분");
        this.writeLine("메모리 사용량 : " + Math.round(process.memoryUsage().heapUsed / 1048576 * 10) / 10 + "/" + Math.round(process.memoryUsage().heapTotal / 1048576 * 10) / 10 + " mb");
        this.writeLine("게임모드 : " + this.gameServer.gameMode.name);
        this.writeLine("Ping : " + this.gameServer.updateTimeAvg.toFixed(3) + " [ms]  (" + ini.getLagMessage(this.gameServer.updateTimeAvg) + ")");
        this.writeLine("----------------------------------------------------------");
    },
};