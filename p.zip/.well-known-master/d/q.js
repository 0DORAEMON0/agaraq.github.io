if(screen.width<=800)window.location="b/";
